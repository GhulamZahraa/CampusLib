using CampusLib.Models;

namespace CampusLib.Models.Interfaces
{
    public interface IDapperBookSearchRepository
    {
        Task<List<Book>> SearchAsync(string? search, int? categoryId, bool availableOnly);
    }
}
