using System.Net.Mail;
using System.Text.RegularExpressions;

namespace CampusLib.Models
{
    public static class PucitEmailHelper
    {
        private const string AllowedDomain = "pucit.edu.pk";

        // The email must use the exact PUCIT domain. This does not verify mailbox ownership.
        public static bool IsValidPucitDomainEmail(string? email)
        {
            if (string.IsNullOrWhiteSpace(email)) return false;

            try
            {
                var address = new MailAddress(email.Trim());
                return address.Address.Equals(email.Trim(), StringComparison.OrdinalIgnoreCase)
                    && address.Host.Equals(AllowedDomain, StringComparison.OrdinalIgnoreCase);
            }
            catch (FormatException)
            {
                return false;
            }
        }

        public static string GetUniversityId(string email)
        {
            var atIndex = email.IndexOf('@');
            return atIndex > 0 ? email[..atIndex].Trim().ToUpperInvariant() : string.Empty;
        }

        public static bool TryGetStudentDetails(string email, out string rollNumber, out string department, out string intake, out string shift)
        {
            rollNumber = GetUniversityId(email);
            department = string.Empty;
            intake = string.Empty;
            shift = string.Empty;

            // Examples: BSEF24M001, BCSF24A070, BSAIF24M015, BSITF24M020, BSSF24A010
            var match = Regex.Match(rollNumber,
                @"^(?<dept>BSE|BCS|BSAI|BSIT|BSS)F(?<year>\d{2})(?<shift>[MA])(?<number>\d{3})$",
                RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

            if (!match.Success) return false;

            var number = int.Parse(match.Groups["number"].Value);
            if (number < 1 || number > 70) return false;

            var departmentCode = match.Groups["dept"].Value.ToUpperInvariant();
            department = departmentCode switch
            {
                "BSE" => "BSSE - Software Engineering",
                "BCS" => "BSCS - Computer Science",
                "BSAI" => "BSAI - Artificial Intelligence",
                "BSIT" => "BSIT - Information Technology",
                "BSS" => "BSS",
                _ => string.Empty
            };

            intake = "Fall 20" + match.Groups["year"].Value;
            shift = match.Groups["shift"].Value.Equals("M", StringComparison.OrdinalIgnoreCase) ? "Morning" : "Afternoon";
            return department.Length > 0;
        }
    }
}
