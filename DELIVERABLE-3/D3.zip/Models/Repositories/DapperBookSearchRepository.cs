using CampusLib.Models;
using CampusLib.Models.Interfaces;
using Dapper;
using Microsoft.Data.SqlClient;

namespace CampusLib.Models.Repositories
{
    // Dapper is used for the live AJAX catalog search; EF Core remains in use
    // for the existing CRUD and circulation repositories.
    public class DapperBookSearchRepository : IDapperBookSearchRepository
    {
        private readonly string _connectionString;

        public DapperBookSearchRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection")
                ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
        }

        public async Task<List<Book>> SearchAsync(string? search, int? categoryId, bool availableOnly)
        {
            const string sql = @"
                SELECT
                    b.Id, b.Title, b.Author, b.ISBN, b.ShelfCode, b.PublishYear, b.Pages,
                    b.TotalCopies, b.AvailableCopies, b.CoverImagePath, b.CoverTone,
                    b.Description, b.IsFeatured, b.CategoryId,
                    c.Id, c.Name, c.Wing, c.Description
                FROM Books AS b
                INNER JOIN Categories AS c ON c.Id = b.CategoryId
                WHERE
                    (@Search IS NULL OR @Search = '' OR
                     b.Title LIKE '%' + @Search + '%' OR
                     b.Author LIKE '%' + @Search + '%' OR
                     b.ISBN LIKE '%' + @Search + '%' OR
                     b.ShelfCode LIKE '%' + @Search + '%')
                    AND (@CategoryId IS NULL OR @CategoryId <= 0 OR b.CategoryId = @CategoryId)
                    AND (@AvailableOnly = 0 OR b.AvailableCopies > 0)
                ORDER BY b.IsFeatured DESC, b.Title;";

            await using var connection = new SqlConnection(_connectionString);
            var rows = await connection.QueryAsync<Book, Category, Book>(
                sql,
                (book, category) =>
                {
                    book.Category = category;
                    return book;
                },
                new
                { Search = search?.Trim(), CategoryId = categoryId, AvailableOnly = availableOnly },
                splitOn: "Id");

            return rows.ToList();
        }
    }
}
