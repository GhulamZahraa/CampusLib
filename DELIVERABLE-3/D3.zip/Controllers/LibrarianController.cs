using CampusLib.Models;
using CampusLib.Models.Interfaces;
using CampusLib.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CampusLib.Controllers
{
    [Authorize(Roles = "Librarian")]
    public class LibrarianController : Controller
    {
        private readonly IBookRepository _books;
        private readonly ICategoryRepository _categories;
        private readonly ICirculationRepository _circulation;

        public LibrarianController(
            IBookRepository books,
            ICategoryRepository categories,
            ICirculationRepository circulation)
        {
            _books = books;
            _categories = categories;
            _circulation = circulation;
        }

        public async Task<IActionResult> Index()
        {
            var books = await _books.GetAllAsync();
            var requests = await _circulation.GetAllRequestsAsync();
            var issues = await _circulation.GetAllIssuesAsync();

            var vm = new LibrarianDashboardViewModel
            {
                TotalCatalogCopies = books.Sum(b => b.TotalCopies),
                PendingRequestsCount = requests.Count(r => r.Status == RequestStatus.Pending),
                ActiveIssuesCount = issues.Count(i => i.Status != IssueStatus.Returned),
                Books = books,
                Categories = await _categories.GetAllWithBookCountAsync(),
                Requests = requests,
                Issues = issues
            };
            return View(vm);
        }

        public async Task<IActionResult> ManageBooks()
        {
            ViewBag.Categories = await _categories.GetAllWithBookCountAsync();
            return View(await _books.GetAllAsync());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddBook(Book model)
        {
            model.AvailableCopies = model.TotalCopies;
            await _books.AddAsync(model);
            TempData["StatusMessage"] = $"Added \"{model.Title}\" to catalog.";
            return RedirectToAction(nameof(ManageBooks));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteBook(int id)
        {
            await _books.DeleteAsync(id);
            TempData["StatusMessage"] = "Volume removed from catalog.";
            return RedirectToAction(nameof(ManageBooks));
        }

        public async Task<IActionResult> IssueRequests()
        {
            return View(await _circulation.GetAllRequestsAsync());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveRequest(int requestId)
        {
            var (_, message) = await _circulation.ApproveRequestAsync(requestId);
            TempData["StatusMessage"] = message;
            return RedirectToAction(nameof(IssueRequests));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RejectRequest(int requestId)
        {
            await _circulation.RejectRequestAsync(requestId);
            TempData["StatusMessage"] = "Request declined.";
            return RedirectToAction(nameof(IssueRequests));
        }

        public async Task<IActionResult> ManageIssues()
        {
            return View(await _circulation.GetAllIssuesAsync());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ReturnBook(int issueId)
        {
            await _circulation.ReturnBookAsync(issueId);
            TempData["StatusMessage"] = "Book returned to shelf.";
            return RedirectToAction(nameof(ManageIssues));
        }
    }
}
