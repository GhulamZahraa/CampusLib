using CampusLib.Models.Interfaces;
using CampusLib.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace CampusLib.Controllers
{
    public class BooksController : Controller
    {
        private readonly IBookRepository _books;
        private readonly ICategoryRepository _categories;
        private readonly IDapperBookSearchRepository _dapperSearch;

        public BooksController(IBookRepository books, ICategoryRepository categories, IDapperBookSearchRepository dapperSearch)
        {
            _books = books;
            _categories = categories;
            _dapperSearch = dapperSearch;
        }

        public async Task<IActionResult> Index(string? q, int? categoryId, bool availableOnly = false)
        {
            var vm = new CatalogViewModel
            {
                Books = await _books.GetAllAsync(q, categoryId, availableOnly),
                Categories = await _categories.GetAllWithBookCountAsync(),
                SearchQuery = q,
                SelectedCategoryId = categoryId,
                AvailableOnly = availableOnly
            };
            return View(vm);
        }

        // AJAX endpoint returning partial HTML cards for live filtering
        [HttpGet]
        public async Task<IActionResult> SearchPartial(string? q, int? categoryId, bool availableOnly = false)
        {
            var results = await _dapperSearch.SearchAsync(q, categoryId, availableOnly);
            return PartialView("_BookGridPartial", results);
        }

        public async Task<IActionResult> Details(int id)
        {
            var book = await _books.GetByIdAsync(id);
            if (book is null) return NotFound();
            return View(book);
        }
    }
}
