using CampusLib.Models;
using CampusLib.Models.Interfaces;
using CampusLib.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CampusLib.Controllers
{
    public class HomeController : Controller
    {
        private readonly IBookRepository _books;

        public HomeController(IBookRepository books)
        {
            _books = books;
        }

        public async Task<IActionResult> Index()
        {
            var vm = new CatalogViewModel
            {
                Books = await _books.GetFeaturedAsync(4)
            };
            return View(vm);
        }

        public IActionResult Privacy() => View();

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            });
        }
    }
}
