using CampusLib.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace CampusLib.Areas.Identity.Pages.Account
{
    public class RegisterModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public RegisterModel(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public class InputModel
        {
            [Required, Display(Name = "Full Name")]
            public string FullName { get; set; } = string.Empty;

            [Required, EmailAddress]
            [Display(Name = "PUCIT Email Address")]
            public string Email { get; set; } = string.Empty;

            [Required, StringLength(100, MinimumLength = 6), DataType(DataType.Password)]
            public string Password { get; set; } = string.Empty;

            [DataType(DataType.Password), Compare("Password", ErrorMessage = "Passwords do not match.")]
            [Display(Name = "Confirm Password")]
            public string ConfirmPassword { get; set; } = string.Empty;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();

            var normalizedEmail = Input.Email.Trim().ToLowerInvariant();
            if (!PucitEmailHelper.IsValidPucitDomainEmail(normalizedEmail))
            {
                ModelState.AddModelError("Input.Email", "Please use your university email ending exactly with @pucit.edu.pk.");
                return Page();
            }

            // Staff accounts are seeded by the application and cannot use public student registration.
            if (normalizedEmail is "admin@pucit.edu.pk" or "librarian@pucit.edu.pk")
            {
                ModelState.AddModelError("Input.Email", "This address is reserved for a staff account. Please sign in.");
                return Page();
            }

            if (!PucitEmailHelper.TryGetStudentDetails(normalizedEmail, out var rollNumber, out var department, out var intake, out var shift))
            {
                ModelState.AddModelError("Input.Email", "Enter a valid PUCIT student roll-number email. Allowed departments: BSSE, BSCS, BSAI, BSIT and BSS. Roll numbers 001–070 are accepted for Morning (M) or Afternoon (A) sections.");
                return Page();
            }

            var existingRollNumber = await _userManager.Users.AnyAsync(u => u.StudentOrStaffId == rollNumber);
            if (existingRollNumber)
            {
                ModelState.AddModelError("Input.Email", "An account with this student roll number already exists.");
                return Page();
            }

            var user = new ApplicationUser
            {
                UserName = normalizedEmail,
                Email = normalizedEmail,
                FullName = Input.FullName.Trim(),
                StudentOrStaffId = rollNumber,
                Department = department,
                SemesterOrTitle = $"{intake} Intake · {shift}",
                EmailConfirmed = false
            };

            var result = await _userManager.CreateAsync(user, Input.Password);
            if (result.Succeeded)
            {
                var roleResult = await _userManager.AddToRoleAsync(user, "Student");
                if (!roleResult.Succeeded)
                {
                    await _userManager.DeleteAsync(user);
                    foreach (var error in roleResult.Errors) ModelState.AddModelError(string.Empty, error.Description);
                    return Page();
                }

                await _signInManager.SignInAsync(user, isPersistent: false);
                return RedirectToAction("Index", "Student");
            }

            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
            return Page();
        }
    }
}
