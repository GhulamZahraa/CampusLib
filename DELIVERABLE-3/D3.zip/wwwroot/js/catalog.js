(() => {
    const searchInput = document.getElementById("liveSearchInput");
    const categorySelect = document.getElementById("categoryFilter");
    const availableOnly = document.getElementById("availableOnlyCheck");
    const resultsContainer = document.getElementById("catalogGridContainer");

    // This script is also loaded by the shared layout, so safely exit on other pages.
    if (!searchInput || !categorySelect || !availableOnly || !resultsContainer) return;

    let debounceTimer;

    async function refreshCatalog() {
        const params = new URLSearchParams({
            q: searchInput.value || "",
            categoryId: categorySelect.value || "",
            availableOnly: availableOnly.checked ? "true" : "false"
        });

        resultsContainer.setAttribute("aria-busy", "true");
        try {
            const response = await fetch(`/Books/SearchPartial?${params.toString()}`, {
                headers: { "X-Requested-With": "XMLHttpRequest" }
            });
            if (response.ok) {
                resultsContainer.innerHTML = await response.text();
            }
        } catch (error) {
            console.error("Could not refresh the book catalog.", error);
        } finally {
            resultsContainer.removeAttribute("aria-busy");
        }
    }

    searchInput.addEventListener("input", () => {
        window.clearTimeout(debounceTimer);
        debounceTimer = window.setTimeout(refreshCatalog, 250);
    });
    categorySelect.addEventListener("change", refreshCatalog);
    availableOnly.addEventListener("change", refreshCatalog);
})();
