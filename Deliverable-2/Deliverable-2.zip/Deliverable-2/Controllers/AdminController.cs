using CampusLib.Models;
using CampusLib.Models.Interfaces;
using CampusLib.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusLib.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ICategoryRepository _categories;
        private readonly ICirculationRepository _circulation;

        public AdminController(
            UserManager<ApplicationUser> userManager,
            ICategoryRepository categories,
            ICirculationRepository circulation)
        {
            _userManager = userManager;
            _categories = categories;
            _circulation = circulation;
        }

        public async Task<IActionResult> Index()
        {
            var users = await _userManager.Users.ToListAsync();
            var list = new List<UserRoleItem>();
            foreach (var u in users)
            {
                var roles = await _userManager.GetRolesAsync(u);
                list.Add(new UserRoleItem
                {
                    Id = u.Id,
                    FullName = u.FullName,
                    Email = u.Email ?? string.Empty,
                    Department = u.Department,
                    StudentOrStaffId = u.StudentOrStaffId,
                    Role = roles.FirstOrDefault() ?? "Student",
                    IsActive = u.IsActive
                });
            }

            var vm = new AdminDashboardViewModel
            {
                Users = list,
                Categories = await _categories.GetAllWithBookCountAsync(),
                TotalLoans = (await _circulation.GetAllIssuesAsync()).Count
            };
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangeRole(string userId, string role)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user is not null)
            {
                var current = await _userManager.GetRolesAsync(user);
                await _userManager.RemoveFromRolesAsync(user, current);
                await _userManager.AddToRoleAsync(user, role);
                TempData["StatusMessage"] = $"Updated {user.FullName} to {role}.";
            }
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddCategory(Category model)
        {
            await _categories.AddAsync(model);
            TempData["StatusMessage"] = $"Added category \"{model.Name}\".";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            var ok = await _categories.DeleteAsync(id);
            TempData["StatusMessage"] = ok
                ? "Category deleted."
                : "Cannot delete a category that still has books assigned.";
            return RedirectToAction(nameof(Index));
        }
    }
}
