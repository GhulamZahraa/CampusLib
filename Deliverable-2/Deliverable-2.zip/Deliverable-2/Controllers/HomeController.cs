using CampusLib.Models;
using CampusLib.Models.Interfaces;
using CampusLib.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CampusLib.Controllers
{
    public class HomeController : Controller
    {
        private readonly IBookRepository _books;
        private readonly ICategoryRepository _categories;

        public HomeController(IBookRepository books, ICategoryRepository categories)
        {
            _books = books;
            _categories = categories;
        }

        public async Task<IActionResult> Index()
        {
            var vm = new CatalogViewModel
            {
                Books = await _books.GetFeaturedAsync(4),
                Categories = await _categories.GetAllWithBookCountAsync()
            };
            return View(vm);
        }

        public IActionResult Privacy() => View();

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            });
        }
    }
}
