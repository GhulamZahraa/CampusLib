using CampusLib.Models;
using CampusLib.Models.Interfaces;
using CampusLib.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace CampusLib.Controllers
{
    [Authorize(Roles = "Student,Librarian,Admin")]
    public class StudentController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IBookRepository _books;
        private readonly ICirculationRepository _circulation;

        public StudentController(
            UserManager<ApplicationUser> userManager,
            IBookRepository books,
            ICirculationRepository circulation)
        {
            _userManager = userManager;
            _books = books;
            _circulation = circulation;
        }

        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user is null) return Challenge();

            var vm = new StudentDashboardViewModel
            {
                User = user,
                Issues = await _circulation.GetIssuesByUserAsync(user.Id),
                Requests = await _circulation.GetRequestsByUserAsync(user.Id)
            };
            return View(vm);
        }

        public async Task<IActionResult> BrowseBooks(string? q)
        {
            var books = await _books.GetAllAsync(q);
            ViewBag.SearchQuery = q;
            return View(books);
        }

        public async Task<IActionResult> MyBooks()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user is null) return Challenge();
            return View(await _circulation.GetIssuesByUserAsync(user.Id));
        }

        public async Task<IActionResult> MyRequests()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user is null) return Challenge();
            return View(await _circulation.GetRequestsByUserAsync(user.Id));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RequestBook(int bookId, string? notes)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user is null) return Challenge();

            var (_, message) = await _circulation.CreateRequestAsync(bookId, user.Id, notes);
            TempData["StatusMessage"] = message;
            return RedirectToAction(nameof(MyRequests));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CancelRequest(int requestId)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user is null) return Challenge();
            await _circulation.CancelRequestAsync(requestId, user.Id);
            TempData["StatusMessage"] = "Book request cancelled.";
            return RedirectToAction(nameof(MyRequests));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RenewBook(int issueId)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user is null) return Challenge();
            await _circulation.RenewBookAsync(issueId, user.Id);
            TempData["StatusMessage"] = "Loan extended by 7 days.";
            return RedirectToAction(nameof(MyBooks));
        }
    }
}
