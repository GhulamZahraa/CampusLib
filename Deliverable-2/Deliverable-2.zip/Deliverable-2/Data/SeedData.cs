using CampusLib.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace CampusLib.Data
{
    public static class SeedData
    {
        public static async Task InitializeAsync(IServiceProvider services)
        {
            if (EF.IsDesignTime) return;

            var context = services.GetRequiredService<ApplicationDbContext>();
            if (!context.Database.GetMigrations().Any())
            {
                // Run Add-Migration InitialCreate and Update-Database first
                return;
            }

            await context.Database.MigrateAsync();

            var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();

            string[] roles = { "Admin", "Librarian", "Student" };
            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    await roleManager.CreateAsync(new IdentityRole(role));
                }
            }

            await EnsureUserAsync(userManager, new ApplicationUser
            {
                UserName = "admin@admin.pucit.edu.pk",
                Email = "admin@admin.pucit.edu.pk",
                FullName = "Dr. Salman Qureshi",
                Department = "University Library Directorate",
                StudentOrStaffId = "ADM-001",
                SemesterOrTitle = "Chief Systems Administrator",
                EmailConfirmed = true
            }, "Campus@2026", "Admin");

            await EnsureUserAsync(userManager, new ApplicationUser
            {
                UserName = "librarian@library.pucit.edu.pk",
                Email = "librarian@library.pucit.edu.pk",
                FullName = "Amina Khalid",
                Department = "Central Circulation Desk",
                StudentOrStaffId = "LIB-STAFF-09",
                SemesterOrTitle = "Senior Circulation Librarian",
                EmailConfirmed = true
            }, "Campus@2026", "Librarian");

            var student = await EnsureUserAsync(userManager, new ApplicationUser
            {
                UserName = "bsef24m001@pucit.edu.pk",
                Email = "bsef24m001@pucit.edu.pk",
                FullName = "Zahra Ghulam",
                Department = "Software Engineering",
                StudentOrStaffId = "BSEF24M001",
                SemesterOrTitle = "BS · Fall 2024 · Morning",
                EmailConfirmed = true
            }, "Campus@2026", "Student");

            if (!await context.Categories.AnyAsync())
            {
                var categories = new List<Category>
                {
                    new() { Name = "Computer Science", Wing = "North Wing · Floor 2", Description = "Algorithms, distributed systems, compilers, and machine intelligence." },
                    new() { Name = "Architecture", Wing = "East Pavilion · Floor 1", Description = "Spatial theory, timber tectonics, urban form, and landscape design." },
                    new() { Name = "Life Sciences", Wing = "Science Annex · Floor 3", Description = "Botanical anatomy, cellular physiology, ecology, and genetics." },
                    new() { Name = "Literature", Wing = "Founders Hall · Mezzanine", Description = "World anthologies, critical essays, translations, and classical prose." },
                    new() { Name = "Economics", Wing = "South Gallery · Floor 2", Description = "Public policy, institutional history, and quantitative econometrics." }
                };

                context.Categories.AddRange(categories);
                await context.SaveChangesAsync();

                var cs = categories[0].Id;
                var arch = categories[1].Id;
                var bio = categories[2].Id;
                var lit = categories[3].Id;

                var books = new List<Book>
                {
                    new() { Title = "Networks in Computation", Author = "Eliza Houghton & Arjun Desai", ISBN = "978-1-4028-9462-1", ShelfCode = "CS-204", PublishYear = 2024, Pages = 486, TotalCopies = 6, AvailableCopies = 5, CoverImagePath = "/images/books/algorithms.jpg", CoverTone = "forest", IsFeatured = true, CategoryId = cs, Description = "Graph algorithms, spectral routing, and fault-tolerant distributed protocols." },
                    new() { Title = "Arch & Form: Spatial Principles", Author = "Sophie Elias", ISBN = "978-0-8109-4418-3", ShelfCode = "AR-112", PublishYear = 2023, Pages = 342, TotalCopies = 4, AvailableCopies = 4, CoverImagePath = "/images/books/architecture.jpg", CoverTone = "sage", IsFeatured = true, CategoryId = arch, Description = "Proportion, daylight modulation, and structural clarity in academic buildings." },
                    new() { Title = "Stories of the World", Author = "Prof. Mirabel Okafor (Ed.)", ISBN = "978-0-14-312774-8", ShelfCode = "LT-088", PublishYear = 2022, Pages = 720, TotalCopies = 5, AvailableCopies = 5, CoverImagePath = "/images/books/literature.jpg", CoverTone = "ivory", IsFeatured = true, CategoryId = lit, Description = "Annotated comparative anthology spanning classical essays and world short fiction." },
                    new() { Title = "Botanica Cellularis", Author = "Eleanor J. Reed & Arthur Vance", ISBN = "978-0-521-88412-9", ShelfCode = "LS-319", PublishYear = 2024, Pages = 564, TotalCopies = 5, AvailableCopies = 5, CoverTone = "pine", IsFeatured = true, CategoryId = bio, Description = "Botanical histology and vascular plant physiology for laboratory courses." },
                    new() { Title = "Systems Architecture with .NET", Author = "Clara Lind & Bilal Siddiqui", ISBN = "978-1-098-15220-4", ShelfCode = "CS-231", PublishYear = 2025, Pages = 528, TotalCopies = 7, AvailableCopies = 7, CoverTone = "forest", CategoryId = cs, Description = "Clean dependency injection, repository abstractions, and resilient web MVC architectures." }
                };

                context.Books.AddRange(books);
                await context.SaveChangesAsync();

                if (student is not null)
                {
                    context.BookIssues.Add(new BookIssue
                    {
                        BookId = books[0].Id,
                        UserId = student.Id,
                        IssuedAt = DateTime.UtcNow.AddDays(-5),
                        DueDate = DateTime.UtcNow.AddDays(9),
                        Status = IssueStatus.Issued
                    });
                    await context.SaveChangesAsync();
                }
            }
        }

        private static async Task<ApplicationUser?> EnsureUserAsync(
            UserManager<ApplicationUser> userManager,
            ApplicationUser user,
            string password,
            string role)
        {
            var existing = await userManager.FindByEmailAsync(user.Email!);
            if (existing is not null) return existing;

            var result = await userManager.CreateAsync(user, password);
            if (result.Succeeded)
            {
                await userManager.AddToRoleAsync(user, role);
                return user;
            }
            return null;
        }
    }
}
