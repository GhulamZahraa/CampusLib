using CampusLib.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace CampusLib.Areas.Identity.Pages.Account
{
    public class RegisterModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public RegisterModel(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public class InputModel
        {
            [Required, Display(Name = "Full Name")]
            public string FullName { get; set; } = string.Empty;

            [Required, EmailAddress]
            [RegularExpression(@"^[bm](se|cs|it|ds|ai)[fs]\d{2}[mae]\d{3}@pucit\.edu\.pk$",
                ErrorMessage = "Enter a valid PUCIT student email like bsef24m001@pucit.edu.pk")]
            [Display(Name = "PUCIT Student Email")]
            public string Email { get; set; } = string.Empty;

            [Required, StringLength(100, MinimumLength = 6), DataType(DataType.Password)]
            public string Password { get; set; } = string.Empty;

            [DataType(DataType.Password), Compare("Password", ErrorMessage = "Passwords do not match.")]
            [Display(Name = "Confirm Password")]
            public string ConfirmPassword { get; set; } = string.Empty;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();

            var parsed = PucitEmailHelper.ParseStudentEmail(Input.Email);
            if (parsed is null)
            {
                ModelState.AddModelError("Input.Email", "Format must match bsef24m001@pucit.edu.pk (degree + program + f/s + year + m/a/e + 3-digit roll).");
                return Page();
            }

            var user = new ApplicationUser
            {
                UserName = Input.Email.Trim().ToLowerInvariant(),
                Email = Input.Email.Trim().ToLowerInvariant(),
                FullName = Input.FullName.Trim(),
                StudentOrStaffId = parsed.Value.RollNo,
                Department = parsed.Value.Department,
                SemesterOrTitle = parsed.Value.BatchStanding,
                EmailConfirmed = true
            };

            var result = await _userManager.CreateAsync(user, Input.Password);
            if (result.Succeeded)
            {
                await _userManager.AddToRoleAsync(user, "Student");
                await _signInManager.SignInAsync(user, isPersistent: false);
                return RedirectToAction("Index", "Student");
            }

            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
            return Page();
        }
    }
}
