using CampusLib.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace CampusLib.Areas.Identity.Pages.Account
{
    public class LoginModel : PageModel
    {
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly UserManager<ApplicationUser> _userManager;

        public LoginModel(SignInManager<ApplicationUser> signInManager, UserManager<ApplicationUser> userManager)
        {
            _signInManager = signInManager;
            _userManager = userManager;
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public class InputModel
        {
            [Required, EmailAddress]
            public string Email { get; set; } = string.Empty;

            [Required, DataType(DataType.Password)]
            public string Password { get; set; } = string.Empty;

            [Display(Name = "Remember me")]
            public bool RememberMe { get; set; }
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();

            if (!PucitEmailHelper.IsValidPucitDomainEmail(Input.Email))
            {
                ModelState.AddModelError("Input.Email", "Use a valid PUCIT email (e.g. bsef24m001@pucit.edu.pk, @library.pucit.edu.pk, or @admin.pucit.edu.pk).");
                return Page();
            }

            var result = await _signInManager.PasswordSignInAsync(Input.Email, Input.Password, Input.RememberMe, lockoutOnFailure: false);
            if (result.Succeeded)
            {
                var user = await _userManager.FindByEmailAsync(Input.Email);
                if (user is not null)
                {
                    if (await _userManager.IsInRoleAsync(user, "Admin")) return RedirectToAction("Index", "Admin");
                    if (await _userManager.IsInRoleAsync(user, "Librarian")) return RedirectToAction("Index", "Librarian");
                }
                return RedirectToAction("Index", "Student");
            }

            ModelState.AddModelError(string.Empty, "Invalid campus email or password.");
            return Page();
        }
    }
}
