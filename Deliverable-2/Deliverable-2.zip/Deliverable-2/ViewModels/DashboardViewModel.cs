using CampusLib.Models;

namespace CampusLib.ViewModels
{
    public class StudentDashboardViewModel
    {
        public ApplicationUser User { get; set; } = new();
        public List<BookIssue> Issues { get; set; } = new();
        public List<BookRequest> Requests { get; set; } = new();
    }

    public class LibrarianDashboardViewModel
    {
        public int TotalCatalogCopies { get; set; }
        public int PendingRequestsCount { get; set; }
        public int ActiveIssuesCount { get; set; }
        public List<Book> Books { get; set; } = new();
        public List<Category> Categories { get; set; } = new();
        public List<BookRequest> Requests { get; set; } = new();
        public List<BookIssue> Issues { get; set; } = new();
    }

    public class AdminDashboardViewModel
    {
        public List<UserRoleItem> Users { get; set; } = new();
        public List<Category> Categories { get; set; } = new();
        public int TotalLoans { get; set; }
    }

    public class UserRoleItem
    {
        public string Id { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
        public string StudentOrStaffId { get; set; } = string.Empty;
        public string Role { get; set; } = "Student";
        public bool IsActive { get; set; }
    }
}
