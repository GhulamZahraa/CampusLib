using CampusLib.Models;

namespace CampusLib.ViewModels
{
    public class CatalogViewModel
    {
        public List<Book> Books { get; set; } = new();
        public List<Category> Categories { get; set; } = new();
        public string? SearchQuery { get; set; }
        public int? SelectedCategoryId { get; set; }
        public bool AvailableOnly { get; set; }
    }
}
