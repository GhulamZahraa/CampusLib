using System.ComponentModel.DataAnnotations;

namespace CampusLib.Models
{
    public class Category
    {
        public int Id { get; set; }

        [Required]
        [StringLength(80)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [StringLength(80)]
        public string Wing { get; set; } = "Main Building";

        [StringLength(240)]
        public string Description { get; set; } = string.Empty;

        public ICollection<Book> Books { get; set; } = new List<Book>();
    }
}
