using CampusLib.Data;
using CampusLib.Models.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace CampusLib.Models.Repositories
{
    public class BookRepository : IBookRepository
    {
        private readonly ApplicationDbContext _db;

        public BookRepository(ApplicationDbContext db)
        {
            _db = db;
        }

        public async Task<List<Book>> GetAllAsync(string? search = null, int? categoryId = null, bool availableOnly = false)
        {
            var query = _db.Books.Include(b => b.Category).AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                var q = search.Trim().ToLower();
                query = query.Where(b =>
                    b.Title.ToLower().Contains(q) ||
                    b.Author.ToLower().Contains(q) ||
                    b.ISBN.ToLower().Contains(q) ||
                    b.ShelfCode.ToLower().Contains(q));
            }

            if (categoryId.HasValue && categoryId.Value > 0)
            {
                query = query.Where(b => b.CategoryId == categoryId.Value);
            }

            if (availableOnly)
            {
                query = query.Where(b => b.AvailableCopies > 0);
            }

            return await query.OrderByDescending(b => b.IsFeatured).ThenBy(b => b.Title).ToListAsync();
        }

        public async Task<List<Book>> GetFeaturedAsync(int count = 4)
        {
            return await _db.Books
                .Include(b => b.Category)
                .OrderByDescending(b => b.IsFeatured)
                .Take(count)
                .ToListAsync();
        }

        public async Task<Book?> GetByIdAsync(int id)
        {
            return await _db.Books.Include(b => b.Category).FirstOrDefaultAsync(b => b.Id == id);
        }

        public async Task AddAsync(Book book)
        {
            _db.Books.Add(book);
            await _db.SaveChangesAsync();
        }

        public async Task UpdateAsync(Book book)
        {
            _db.Books.Update(book);
            await _db.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var book = await _db.Books.FindAsync(id);
            if (book is not null)
            {
                _db.Books.Remove(book);
                await _db.SaveChangesAsync();
            }
        }
    }
}
