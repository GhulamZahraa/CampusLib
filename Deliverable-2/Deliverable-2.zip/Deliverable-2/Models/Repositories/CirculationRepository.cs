using CampusLib.Data;
using CampusLib.Models.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace CampusLib.Models.Repositories
{
    public class CirculationRepository : ICirculationRepository
    {
        private readonly ApplicationDbContext _db;

        public CirculationRepository(ApplicationDbContext db)
        {
            _db = db;
        }

        public async Task<List<BookRequest>> GetRequestsByUserAsync(string userId)
        {
            return await _db.BookRequests
                .Include(r => r.Book)
                .Where(r => r.UserId == userId)
                .OrderByDescending(r => r.RequestedAt)
                .ToListAsync();
        }

        public async Task<List<BookRequest>> GetAllRequestsAsync()
        {
            return await _db.BookRequests
                .Include(r => r.Book)
                .Include(r => r.User)
                .OrderByDescending(r => r.RequestedAt)
                .ToListAsync();
        }

        public async Task<List<BookIssue>> GetIssuesByUserAsync(string userId)
        {
            return await _db.BookIssues
                .Include(i => i.Book)
                .Where(i => i.UserId == userId)
                .OrderByDescending(i => i.IssuedAt)
                .ToListAsync();
        }

        public async Task<List<BookIssue>> GetAllIssuesAsync()
        {
            return await _db.BookIssues
                .Include(i => i.Book)
                .Include(i => i.User)
                .OrderByDescending(i => i.IssuedAt)
                .ToListAsync();
        }

        public async Task<(bool Success, string Message)> CreateRequestAsync(int bookId, string userId, string? notes)
        {
            var book = await _db.Books.FindAsync(bookId);
            if (book is null) return (false, "Book not found.");
            if (book.AvailableCopies <= 0) return (false, "No copies currently available on shelf.");

            var duplicate = await _db.BookRequests.AnyAsync(r =>
                r.BookId == bookId && r.UserId == userId && r.Status == RequestStatus.Pending);
            if (duplicate) return (false, "You already have a pending hold request for this volume.");

            _db.BookRequests.Add(new BookRequest
            {
                BookId = bookId,
                UserId = userId,
                Notes = notes,
                Status = RequestStatus.Pending,
                RequestedAt = DateTime.UtcNow
            });

            await _db.SaveChangesAsync();
            return (true, $"Hold request submitted for \"{book.Title}\".");
        }

        public async Task<bool> CancelRequestAsync(int requestId, string userId)
        {
            var req = await _db.BookRequests.FirstOrDefaultAsync(r => r.Id == requestId && r.UserId == userId);
            if (req is null || req.Status != RequestStatus.Pending) return false;
            req.Status = RequestStatus.Cancelled;
            await _db.SaveChangesAsync();
            return true;
        }

        public async Task<(bool Success, string Message)> ApproveRequestAsync(int requestId)
        {
            var req = await _db.BookRequests.Include(r => r.Book).FirstOrDefaultAsync(r => r.Id == requestId);
            if (req is null || req.Book is null) return (false, "Request not found.");
            if (req.Book.AvailableCopies <= 0) return (false, "No available copies left.");

            req.Status = RequestStatus.Approved;
            req.Book.AvailableCopies -= 1;

            _db.BookIssues.Add(new BookIssue
            {
                BookId = req.BookId,
                UserId = req.UserId,
                IssuedAt = DateTime.UtcNow,
                DueDate = DateTime.UtcNow.AddDays(14),
                Status = IssueStatus.Issued
            });

            await _db.SaveChangesAsync();
            return (true, $"Approved and issued \"{req.Book.Title}\".");
        }

        public async Task<bool> RejectRequestAsync(int requestId)
        {
            var req = await _db.BookRequests.FindAsync(requestId);
            if (req is null || req.Status != RequestStatus.Pending) return false;
            req.Status = RequestStatus.Rejected;
            await _db.SaveChangesAsync();
            return true;
        }

        public async Task<bool> ReturnBookAsync(int issueId)
        {
            var issue = await _db.BookIssues.Include(i => i.Book).FirstOrDefaultAsync(i => i.Id == issueId);
            if (issue is null || issue.Status == IssueStatus.Returned) return false;

            issue.Status = IssueStatus.Returned;
            issue.ReturnedAt = DateTime.UtcNow;
            if (issue.Book is not null && issue.Book.AvailableCopies < issue.Book.TotalCopies)
            {
                issue.Book.AvailableCopies += 1;
            }
            await _db.SaveChangesAsync();
            return true;
        }

        public async Task<bool> RenewBookAsync(int issueId, string userId)
        {
            var issue = await _db.BookIssues.FirstOrDefaultAsync(i => i.Id == issueId && i.UserId == userId);
            if (issue is null || issue.Status == IssueStatus.Returned) return false;
            issue.DueDate = issue.DueDate.AddDays(7);
            issue.Status = IssueStatus.Issued;
            await _db.SaveChangesAsync();
            return true;
        }
    }
}
