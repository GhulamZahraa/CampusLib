using CampusLib.Data;
using CampusLib.Models.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace CampusLib.Models.Repositories
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly ApplicationDbContext _db;

        public CategoryRepository(ApplicationDbContext db)
        {
            _db = db;
        }

        public async Task<List<Category>> GetAllWithBookCountAsync()
        {
            return await _db.Categories.Include(c => c.Books).OrderBy(c => c.Name).ToListAsync();
        }

        public async Task<Category?> GetByIdAsync(int id)
        {
            return await _db.Categories.FindAsync(id);
        }

        public async Task AddAsync(Category category)
        {
            _db.Categories.Add(category);
            await _db.SaveChangesAsync();
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var category = await _db.Categories.Include(c => c.Books).FirstOrDefaultAsync(c => c.Id == id);
            if (category is null || category.Books.Count > 0) return false;
            _db.Categories.Remove(category);
            await _db.SaveChangesAsync();
            return true;
        }
    }
}
