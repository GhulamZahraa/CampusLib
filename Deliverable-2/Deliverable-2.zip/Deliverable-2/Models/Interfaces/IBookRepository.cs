using CampusLib.Models;

namespace CampusLib.Models.Interfaces
{
    public interface IBookRepository
    {
        Task<List<Book>> GetAllAsync(string? search = null, int? categoryId = null, bool availableOnly = false);
        Task<List<Book>> GetFeaturedAsync(int count = 4);
        Task<Book?> GetByIdAsync(int id);
        Task AddAsync(Book book);
        Task UpdateAsync(Book book);
        Task DeleteAsync(int id);
    }
}
