using CampusLib.Models;

namespace CampusLib.Models.Interfaces
{
    public interface ICirculationRepository
    {
        Task<List<BookRequest>> GetRequestsByUserAsync(string userId);
        Task<List<BookRequest>> GetAllRequestsAsync();
        Task<List<BookIssue>> GetIssuesByUserAsync(string userId);
        Task<List<BookIssue>> GetAllIssuesAsync();
        Task<(bool Success, string Message)> CreateRequestAsync(int bookId, string userId, string? notes);
        Task<bool> CancelRequestAsync(int requestId, string userId);
        Task<(bool Success, string Message)> ApproveRequestAsync(int requestId);
        Task<bool> RejectRequestAsync(int requestId);
        Task<bool> ReturnBookAsync(int issueId);
        Task<bool> RenewBookAsync(int issueId, string userId);
    }
}
