using CampusLib.Models;

namespace CampusLib.Models.Interfaces
{
    public interface ICategoryRepository
    {
        Task<List<Category>> GetAllWithBookCountAsync();
        Task<Category?> GetByIdAsync(int id);
        Task AddAsync(Category category);
        Task<bool> DeleteAsync(int id);
    }
}
