using System.ComponentModel.DataAnnotations;

namespace CampusLib.Models
{
    public class Book
    {
        public int Id { get; set; }

        [Required]
        [StringLength(160)]
        public string Title { get; set; } = string.Empty;

        [Required]
        [StringLength(120)]
        public string Author { get; set; } = string.Empty;

        [Required]
        [StringLength(30)]
        public string ISBN { get; set; } = string.Empty;

        [Required]
        [StringLength(24)]
        public string ShelfCode { get; set; } = string.Empty;

        public int PublishYear { get; set; } = 2024;
        public int Pages { get; set; } = 320;

        [Range(1, 500)]
        public int TotalCopies { get; set; } = 1;

        [Range(0, 500)]
        public int AvailableCopies { get; set; } = 1;

        [StringLength(260)]
        public string? CoverImagePath { get; set; }

        [StringLength(24)]
        public string CoverTone { get; set; } = "forest";

        [StringLength(1000)]
        public string Description { get; set; } = string.Empty;

        public bool IsFeatured { get; set; } = false;

        public int CategoryId { get; set; }
        public Category? Category { get; set; }

        public ICollection<BookIssue> BookIssues { get; set; } = new List<BookIssue>();
        public ICollection<BookRequest> BookRequests { get; set; } = new List<BookRequest>();
    }
}
