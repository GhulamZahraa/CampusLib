using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace CampusLib.Models
{
    public class ApplicationUser : IdentityUser
    {
        [Required]
        [StringLength(120)]
        public string FullName { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Department { get; set; } = "Computer Science";

        [Required]
        [StringLength(40)]
        public string StudentOrStaffId { get; set; } = string.Empty;

        [StringLength(80)]
        public string SemesterOrTitle { get; set; } = "Undergraduate";

        public bool IsActive { get; set; } = true;

        public DateTime JoinedDate { get; set; } = DateTime.UtcNow;

        public ICollection<BookIssue> BookIssues { get; set; } = new List<BookIssue>();
        public ICollection<BookRequest> BookRequests { get; set; } = new List<BookRequest>();
    }
}
