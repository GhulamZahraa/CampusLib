using System.Text.RegularExpressions;

namespace CampusLib.Models
{
    public static class PucitEmailHelper
    {
        // Example: bsef24m001@pucit.edu.pk
        // b/m = Bachelors/Masters | se/cs/it/ds/ai = Program | f/s = Fall/Spring | 24 = Year | m/a/e = Morning/Afternoon/Evening | 001 = Roll No
        private static readonly Regex StudentEmailRegex = new(
            @"^(?<level>[bm])(?<prog>se|cs|it|ds|ai)(?<sem>[fs])(?<year>\d{2})(?<shift>[mae])(?<roll>\d{3})@pucit\.edu\.pk$",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

        private static readonly Regex StaffEmailRegex = new(
            @"^[a-z0-9._-]+@(library|admin)\.pucit\.edu\.pk$",
            RegexOptions.IgnoreCase | RegexOptions.Compiled);

        public static bool IsValidStudentEmail(string? email) =>
            !string.IsNullOrWhiteSpace(email) && StudentEmailRegex.IsMatch(email.Trim());

        public static bool IsValidPucitDomainEmail(string? email) =>
            !string.IsNullOrWhiteSpace(email) &&
            (StudentEmailRegex.IsMatch(email.Trim()) || StaffEmailRegex.IsMatch(email.Trim()));

        public static (string RollNo, string Department, string BatchStanding)? ParseStudentEmail(string email)
        {
            var match = StudentEmailRegex.Match(email.Trim());
            if (!match.Success) return null;

            var level = match.Groups["level"].Value.ToLowerInvariant() == "b" ? "BS" : "MS";
            var progCode = match.Groups["prog"].Value.ToLowerInvariant();
            var sem = match.Groups["sem"].Value.ToLowerInvariant() == "f" ? "Fall" : "Spring";
            var year = $"20{match.Groups["year"].Value}";
            var shift = match.Groups["shift"].Value.ToLowerInvariant() switch
            {
                "m" => "Morning",
                "a" => "Afternoon",
                _ => "Evening"
            };

            var department = progCode switch
            {
                "se" => "Software Engineering",
                "cs" => "Computer Science",
                "it" => "Information Technology",
                "ds" => "Data Science",
                "ai" => "Artificial Intelligence",
                _ => "Computing"
            };

            var rollNo = email.Split('@')[0].ToUpperInvariant();
            var standing = $"{level} · {sem} {year} · {shift}";
            return (rollNo, department, standing);
        }
    }
}
