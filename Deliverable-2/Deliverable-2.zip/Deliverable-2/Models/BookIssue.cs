using System.ComponentModel.DataAnnotations;

namespace CampusLib.Models
{
    public enum IssueStatus
    {
        Issued,
        Returned,
        Overdue
    }

    public class BookIssue
    {
        public int Id { get; set; }

        public int BookId { get; set; }
        public Book? Book { get; set; }

        [Required]
        public string UserId { get; set; } = string.Empty;
        public ApplicationUser? User { get; set; }

        public DateTime IssuedAt { get; set; } = DateTime.UtcNow;
        public DateTime DueDate { get; set; } = DateTime.UtcNow.AddDays(14);
        public DateTime? ReturnedAt { get; set; }

        public IssueStatus Status { get; set; } = IssueStatus.Issued;
    }
}
